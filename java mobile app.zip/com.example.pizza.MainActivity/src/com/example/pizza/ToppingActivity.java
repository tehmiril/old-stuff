package com.example.pizza;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class ToppingActivity extends Activity {
	//private TextView test;
	private CheckBox cb_corn, cb_anchovies, cb_pepperoni, cb_mushroom;
	private StringBuffer toppings;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.topping_layout);
        /*
        test = (TextView)findViewById(R.id.test);
        Bundle namecust = getIntent().getExtras();
        //if(namecust != null){
        	String namecus = namecust.getString("Customer Name");
        	String addrcus = namecust.getString("Customer Address");
        	String phonecus = namecust.getString("Phone Number");
        	String shape = namecust.getString("Shape");
        	String cheese = namecust.getString("Cheese");
        	test.setText(namecus + " " + addrcus + " " + phonecus + " " + shape + " " + cheese);
        	*/
        checkboxListener();
    }
    
    public void checkboxListener(){
    	cb_corn = (CheckBox) findViewById(R.id.CornCB);
    	cb_anchovies = (CheckBox)findViewById(R.id.AnchoviesCB);
    	cb_pepperoni = (CheckBox)findViewById(R.id.PepperoniCB);
    	cb_mushroom = (CheckBox)findViewById(R.id.MushroomCB);
    	
    	Bundle namecust = getIntent().getExtras();
        
    	final String namecus = namecust.getString("Customer Name");
    	final String addrcus = namecust.getString("Customer Address");
    	final String phonecus = namecust.getString("Phone Number");
    	final String shape = namecust.getString("Shape");
    	final String cheese = namecust.getString("Cheese");
    	
    	((Button)findViewById(R.id.toppingButton)).setOnClickListener(new OnClickListener() {
			//@Override
			public void onClick(View v) {
				toppings = new StringBuffer();
		    	if (cb_corn.isChecked()){
		    		toppings.append("corns, ");
		    	}
		    	if(cb_anchovies.isChecked()){
		    		toppings.append(" anchovies, ");
		    	}
		    	if(cb_pepperoni.isChecked()){
		    		toppings.append(" pepperonies, ");
		    	}
		    	if(cb_mushroom.isChecked()){
		    		toppings.append(" mushrooms ");
		    	}
		    	String endToppings = toppings.toString();
		    	
		    	Intent itopping = new Intent(getApplicationContext(), SendActivity.class);
    	        itopping.putExtra("Customer Name", namecus);
    	        itopping.putExtra("Customer Address", addrcus);
    	        itopping.putExtra("Phone Number", phonecus);
    	        itopping.putExtra("Shape", shape);
    	        itopping.putExtra("Cheese", cheese);
    	        itopping.putExtra("Toppings", endToppings);
    	        startActivity(itopping);
			}
        });
    	
    		
    }
}
