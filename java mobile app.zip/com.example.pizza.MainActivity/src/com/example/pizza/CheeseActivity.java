package com.example.pizza;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class CheeseActivity extends Activity {
	private RadioGroup cheeseGroup;
	private RadioButton cheeseButton;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cheese_layout);
    cheeseGroup = (RadioGroup) findViewById(R.id.radioCheeseGroup);
        Bundle namecust = getIntent().getExtras();
        
        	final String namecus = namecust.getString("Customer Name");
        	final String addrcus = namecust.getString("Customer Address");
        	final String phonecus = namecust.getString("Phone Number");
        	final String shape = namecust.getString("Shape");
        	
        	cheeseGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
				
				public void onCheckedChanged(RadioGroup group, int checkedId) {
					// TODO Auto-generated method stub
					cheeseButton = (RadioButton) findViewById(checkedId);
					String cheese = (String) cheeseButton.getText();
					Intent icheese = new Intent(getApplicationContext(),ToppingActivity.class);
	    	        icheese.putExtra("Customer Name", namecus);
	    	        icheese.putExtra("Customer Address", addrcus);
	    	        icheese.putExtra("Phone Number", phonecus);
	    	        icheese.putExtra("Shape", shape);
	    	        icheese.putExtra("Cheese", cheese);
	    	        startActivity(icheese);
				}
			});
    
    }
}
