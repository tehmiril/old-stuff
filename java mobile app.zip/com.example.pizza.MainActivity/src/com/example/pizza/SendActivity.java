package com.example.pizza;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class SendActivity extends Activity {
	private TextView order;
	private StringBuffer finalOrder;
	private static final String ORDER_SENT = "ORDER_SENT";
	private static final String ORDER_DELIVERED = "ORDER_DELIVERED";
	private PendingIntent pendingSent = null;
	private PendingIntent pendingDelivered = null;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_layout);
        
        order = (TextView) findViewById(R.id.fullorder);
      
        Bundle namecust = getIntent().getExtras();
        
        	String namecus = namecust.getString("Customer Name");
        	String addrcus = namecust.getString("Customer Address");
        	String phonecus = namecust.getString("Phone Number");
        	String shape = namecust.getString("Shape");
        	String cheese = namecust.getString("Cheese");
        	String toppings = namecust.getString("Toppings");
        	
        	finalOrder = new StringBuffer();
        	finalOrder.append("Customer Name: ").append(namecus).append(". Address: ");
        	finalOrder.append(addrcus).append(". Phone Number: ").append(phonecus);
        	finalOrder.append(". Selected Shape: ").append(shape).append(". Selected Cheese: ").append(cheese);
        	finalOrder.append(". Selected Toppings: ").append(toppings);
        	
        	order.setText(finalOrder.toString());
        	
        	((Button)findViewById(R.id.sendButton)).setOnClickListener(new OnClickListener() {
    		//@Override
    		public void onClick(View v) {	
    			sendOrder(finalOrder.toString(),"+31616978359");
    		}
        });
        	((Button)findViewById(R.id.cancelButton)).setOnClickListener(new OnClickListener() {
        		//@Override
        		public void onClick(View v) {
        			cancelOrder();
        			//cancelStatusUpdates();
        		}
            });
        	//initStatusReceivers();
    }
    /*
    private void initStatusReceivers() {
		// TODO
		IntentFilter sent = new IntentFilter(SendActivity.ORDER_SENT);
		IntentFilter received = new IntentFilter(SendActivity.ORDER_DELIVERED);
		MessageSentReceiver mSReceiver = new MessageSentReceiver();
		MessageDeliveredReceiver mDReceiver = new MessageDeliveredReceiver();
		this.registerReceiver(mSReceiver, sent);
		this.registerReceiver(mDReceiver, received);
	}
    */
    private void sendOrder(String order, String nume) {
		// TODO
		
		pendingSent = PendingIntent.getBroadcast(this, 0,
	            new Intent(SendActivity.ORDER_SENT), 0);
	 
	    pendingDelivered = PendingIntent.getBroadcast(this, 0,
	            new Intent(SendActivity.ORDER_DELIVERED), 0); 
	    
	  //---when the SMS has been sent---
        registerReceiver(new BroadcastReceiver(){
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode())
                {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), R.string.sent, 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        Toast.makeText(getBaseContext(), "Generic failure", 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        Toast.makeText(getBaseContext(), "No service", 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        Toast.makeText(getBaseContext(), "Null PDU", 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        Toast.makeText(getBaseContext(), "Radio off", 
                                Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter(ORDER_SENT));
 
        //---when the SMS has been delivered---
        registerReceiver(new BroadcastReceiver(){
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode())
                {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), R.string.delivered, 
                                Toast.LENGTH_LONG).show();
                        Intent i = new Intent(getBaseContext(), MainActivity.class); 
    					i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); 
    					startActivity(i);
                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(getBaseContext(), "order not delivered", 
                                Toast.LENGTH_SHORT).show();
                        break;                        
                }
            }
        }, new IntentFilter(ORDER_DELIVERED));        
	    
		SmsManager sms = SmsManager.getDefault();
		
		//5566 is the number of emulator destination
		//of course if you want to send it to real phone number, use the actual number and country codes
		sms.sendTextMessage(nume, null, order, pendingSent, pendingDelivered);
		
	}
    /*
    //not yet used
    private void cancelStatusUpdates() {
		// TODO
		pendingSent.cancel();
		pendingDelivered.cancel();
	}
	*/
	private void cancelOrder() {
		//refresh to main activity
		Intent i = new Intent(getBaseContext(), MainActivity.class); 
		i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); 
		startActivity(i);
	}
	/*
    private class MessageSentReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO
			switch (getResultCode())
            {
                case Activity.RESULT_OK:
                	Toast.makeText(getApplicationContext(), R.string.sent, 
                			Toast.LENGTH_LONG).show();  
                	/*
                	// custom dialog
        			final Dialog dialog = new Dialog(context);
        			dialog.setContentView(R.layout.);
        			dialog.setTitle("Status");
         
        			// set the custom dialog components - text, image and button
        			TextView text = (TextView) dialog.findViewById(R.id.text);
        			text.setText(R.string.sent);
        			
        			Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
        			// if button is clicked, close the custom dialog
        			dialogButton.setOnClickListener(new OnClickListener() {
        				@Override
        				public void onClick(View v) {
        					dialog.dismiss();
        					
        					
        					
        				}
        			});
         
        			dialog.show();
        			
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                	Toast.makeText(getApplicationContext(), R.string.error, 
                			Toast.LENGTH_LONG).show();  
                    break;
            }
		}
	}
	
	private class MessageDeliveredReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO
			switch (getResultCode())
			{
			case Activity.RESULT_OK:
				Toast.makeText(getApplicationContext(), R.string.delivered, 
						Toast.LENGTH_SHORT).show();  
			break;
			 //case Activity.RESULT_CANCELED:
             //    Toast.makeText(getBaseContext(), "SMS not delivered", 
             //            Toast.LENGTH_SHORT).show();
             //    break;           
			}
		}
	}
	*/
}
