package com.example.pizza;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.app.Activity;
import android.content.Intent;

public class ShapeActivity extends Activity {
	private RadioGroup shapeGroup;
	private RadioButton shapeButton;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shape_layout);
        
        shapeGroup = (RadioGroup) findViewById(R.id.radioShapeGroup);
        Bundle namecust = getIntent().getExtras();
        //if(namecust != null){
        	final String namecus = namecust.getString("Customer Name");
        	final String addrcus = namecust.getString("Customer Address");
        	final String phonecus = namecust.getString("Phone Number");
        	
        shapeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				shapeButton = (RadioButton)  findViewById(checkedId);
				String shape = (String) shapeButton.getText();
				Intent ishape = new Intent(getApplicationContext(),CheeseActivity.class);
    	        ishape.putExtra("Customer Name", namecus);
    	        ishape.putExtra("Customer Address", addrcus);
    	        ishape.putExtra("Phone Number", phonecus);
    	        ishape.putExtra("Shape", shape);
    	        startActivity(ishape);
			}
		});
       
    }
}
