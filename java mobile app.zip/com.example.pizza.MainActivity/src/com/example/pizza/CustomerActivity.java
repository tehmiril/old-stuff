package com.example.pizza;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.content.Intent;

public class CustomerActivity extends Activity {
	private TextView nameCust;
	private TextView addressCust;
	private TextView phoneCust;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_layout);
        nameCust = (TextView) findViewById(R.id.editNameCust);
		addressCust = (TextView) findViewById(R.id.editAddressCust);
		phoneCust = (TextView) findViewById(R.id.editPhoneCust);
        ((Button)findViewById(R.id.custButton)).setOnClickListener(new OnClickListener() {
    		//@Override
    		public void onClick(View v) {
	
    	        String namecust = nameCust.getText().toString();
    	        String addrcust = addressCust.getText().toString();
    	        String numcust = phoneCust.getText().toString();
    	        if(namecust.length()>0 && addrcust.length()>0 && numcust.length()>0)
    	        {
    	        Intent iname = new Intent(getApplicationContext(),ShapeActivity.class);
    	        iname.putExtra("Customer Name", namecust);
    	        iname.putExtra("Customer Address", addrcust);
    	        iname.putExtra("Phone Number", numcust);
    	        
    	        startActivity(iname);
    	        }
    	        else
    	        {
    	        	 Toast.makeText(getBaseContext(), 
    	                        "Please enter all data correctly.", 
    	                        Toast.LENGTH_LONG).show();
    	        }
          }
            });
        
        
    }
}
