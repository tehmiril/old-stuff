/** Automatically generated file. DO NOT MODIFY */
package com.example.pizza;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}